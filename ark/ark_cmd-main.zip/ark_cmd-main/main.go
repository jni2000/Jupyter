package main

import (
	"github.com/yushihui/ark_cmd/cmd"
)

func main() {
	//cmd.BuildIndex()
	//cmd.SearchActivity("PTON")
	cmd.Execute()
	// yellow := color.New(color.FgYellow).SprintFunc()
	// red := color.New(color.FgRed).SprintFunc()
	// fmt.Printf("This is a %28s and this is %28s.\n", yellow("warning"), red("error"))

}
